package com.example.chatbotapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatbotApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatbotApiApplication.class, args);
    }
}